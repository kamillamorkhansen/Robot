public enum Direction {
    clockwise, counterclockwise;
}
