public enum BinaryOp {
    addition("+"),
    substraction("-"),
    multiplication("*"),
    greater(">"),
    less("<"),
    equal("=");

    BinaryOp(String symbol) {
    }
}
