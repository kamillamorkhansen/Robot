interface Robol {
    void interpret();
}