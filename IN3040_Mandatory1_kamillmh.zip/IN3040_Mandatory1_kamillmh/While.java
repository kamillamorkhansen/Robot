public class While {

    private ArithmeticExp condition;  

    public While(ArithmeticExp condition) {
        this.condition = condition;
    }

    public ArithmeticExp getCondition() {
        return condition;
    }
}
