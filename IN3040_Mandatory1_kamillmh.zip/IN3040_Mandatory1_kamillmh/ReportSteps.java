public class ReportSteps extends Statement {

    @Override
    public void interpret() {
        System.out.println("Total Steps Taken: " + r.getSteps());

    }
    
}
